# GAIH Student Repo Example
![](img/logo.png)

**Course Date:** DD.MM.YYYY  
**Name:** Mert  
**Surname:** Cobanov  
**Email:** mertcobanov@gmail.com  

**Note:** Your homeworks can be formats like ".ipynb" and ".py". **Not ".txt" files!!** Make sure that your codes works.  

## Project Name
Description of your project.

## Requirements
```
Some python libraries
Some python libraries
Some python libraries
```
---

### Certification
![](img/certificate_ex.png)

